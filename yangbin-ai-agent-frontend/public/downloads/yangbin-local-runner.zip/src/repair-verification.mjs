// Count finished test cases, excluding skipped tests, suites and Node's implicit
// "the file exited successfully" test for a file with no registered cases.
const nodeReporter = `
import path from 'node:path';
export default async function* report(events) {
  let testsRun = 0;
  let failures = 0;
  for await (const {type, data} of events) {
    if (type === 'test:stderr' || type === 'test:stdout') {
      process.stderr.write(data.message);
      continue;
    }
    if (type !== 'test:pass' && type !== 'test:fail') continue;
    const fileOnly = data.file && path.resolve(data.name) === path.resolve(data.file);
    if (!data.skip && !data.todo && !fileOnly && data.details?.type !== 'suite') testsRun++;
    if (type === 'test:fail' && !data.todo && !data.skip) {
      failures++;
      yield data.name + ': ' + String(data.details?.error?.cause || data.details?.error || 'failed') + '\\n';
    }
  }
  yield '\\nYANGBIN_TEST_RESULT=' + JSON.stringify({testsRun, failures}) + '\\n';
}`;

// Isolated supervisor; only it writes stdout. Repository logs go to stderr.
// The JUnit report is runner evidence for these repository-controlled tests.
const pytestDriver = `
import json, os, subprocess, sys, tempfile, xml.etree.ElementTree as xml
with tempfile.TemporaryDirectory() as tmp:
    report = os.path.join(tmp, "tests.xml")
    bootstrap = "import os, sys, pytest; sys.path.insert(0, os.getcwd()); sys.exit(pytest.main(sys.argv[1:]))"
    code = subprocess.call([sys.executable, "-I", "-B", "-c", bootstrap, "-q", "-p", "no:cacheprovider",
                            "--junitxml", report, sys.argv[1]], stdout=sys.stderr, stderr=sys.stderr)
    if os.path.isfile(report) and os.stat(report).st_size <= 4194304:
        cases = xml.parse(report).findall(".//testcase")
        failed = [case.find("failure") for case in cases if case.find("failure") is not None]
        # A dependency can also be imported lazily in the body of a test.
        unavailable = sum(f.get("message", "").startswith("ModuleNotFoundError: No module named ") for f in failed)
        failures = len(failed) - unavailable
        errors = sum(case.find("error") is not None for case in cases) + unavailable
        executed = sum(case.find("skipped") is None and case.find("error") is None for case in cases)
        print("YANGBIN_TEST_RESULT=" + json.dumps({"testsRun": executed, "failures": failures, "errors": errors}))
sys.exit(code)`;

export function normalizeTestTarget(runner, target) {
  if (typeof target !== 'string' || target.startsWith('/') || target.endsWith('/') || target.length > 300) {
    throw new Error('Choose a relative test file');
  }
  target = target.split('/').filter(part => part && part !== '.').join('/');
  if (!['node', 'pytest'].includes(runner) || !target.split('/').every(part => /^[\p{L}\p{N}_][\p{L}\p{N}_. -]*$/u.test(part)) ||
      !(runner === 'pytest' ? /\.py$/ : /\.[cm]?js$/).test(target)) {
    throw new Error('Choose a single relative test file and its matching runner');
  }
  return target;
}
export function testInvocation(runner, file) {
  const target = normalizeTestTarget(runner, file);
  if (runner === 'node') {
    const reporter = 'data:text/javascript;base64,' + Buffer.from(nodeReporter).toString('base64');
    return ['node', '--test', '--test-reporter=' + reporter, './' + target];
  }
  return ['python3', '-I', '-B', '-c', pytestDriver, './' + target];
}

export function interpretTestRun({code, stdout, stderr = ''}) {
  const match = /(?:^|\n)YANGBIN_TEST_RESULT=(\{[^\r\n]*\})\s*$/.exec(stdout);
  const diagnostic = (stderr + '\n' + (match ? stdout.slice(0,match.index) : stdout)).trim().slice(-4500);
  let counts;
  try { counts = match && JSON.parse(match[1]); } catch {}
  if (!counts || !Number.isSafeInteger(counts.testsRun) || counts.testsRun < 0 ||
      !Number.isSafeInteger(counts.failures) || counts.failures < 0) {
    return {status: 'BLOCKED', exitCode: code, testsRun: null, diagnostic};
  }
  const {testsRun, failures, errors = 0} = counts;
  let status = 'BLOCKED';
  if (errors === 0) {
    if (code === 0 && failures === 0) status = testsRun > 0 ? 'PASSED' : 'NO_TESTS';
    else if (code === 5 && testsRun === 0 && failures === 0) status = 'NO_TESTS';
    else if (code === 1 && testsRun > 0 && failures > 0) status = 'FAILED';
  }
  return {status, testsRun, exitCode: code, diagnostic};
}

const empty = status => ({status, runner:null, target:null, testsRun:null, exitCode:null, snapshotHash:null, baselineFailed:false});

export class RepairVerification {
  constructor(emit) {
    this.emit = emit;
    this.revision = 0;
    this.generation = 0;
    this.activeWrites = 0;
    this.baselines = new Map();
    this.changedPaths = new Set();
    this.previous = null;
    this.latest = null;
  }
  publish(record) {
    this.latest = {type:'repair_verification', ...record, revision:this.revision};
    this.emit(this.latest);
    return this.latest;
  }
  requested() {
    this.publish(empty('UNVERIFIED'));
  }
  beginWrite() {
    this.activeWrites++;
    this.generation++;
    if (this.latest?.snapshotHash) {
      this.previous = this.latest;
      this.publish(empty('STALE'));
    }
  }
  endWrite(success, path) {
    this.activeWrites--;
    this.generation++;
    if (success) {
      this.revision++;
      this.changedPaths.add(path);
    }
    this.publish(empty(this.latest && this.latest.status !== 'UNVERIFIED' ? 'STALE' : 'UNVERIFIED'));
  }
  beginCheck() {
    return this.generation;
  }
  checked(generation, runner, target, result) {
    if (this.activeWrites || this.generation !== generation) return this.publish(empty('STALE'));
    this.previous = null;
    const {status, exitCode, testsRun, snapshotHash} = result;
    const key = JSON.stringify([runner, target, result.targetHash]);
    if (this.onlyTestChanged(target) && status === 'FAILED' && testsRun > 0) this.baselines.set(key, snapshotHash);
    const baseline = this.baselines.get(key);
    return this.publish({status, runner, target, exitCode, testsRun, snapshotHash,
      baselineFailed: Boolean(!this.onlyTestChanged(target) && baseline && snapshotHash && baseline !== snapshotHash)});
  }
  onlyTestChanged(target) {
    return this.changedPaths.size === 0 || (this.changedPaths.size === 1 && this.changedPaths.has(target));
  }
  async refresh(hashWorkspace) {
    const last = this.latest;
    const candidate = last?.snapshotHash ? last : last?.status === 'STALE' ? this.previous : null;
    if (!candidate || this.activeWrites) return;
    let current;
    try { current = await hashWorkspace(); } catch {}
    if (this.latest !== last) return;
    if (candidate.snapshotHash !== current) {
      this.previous = null;
      if (last.status !== 'STALE') this.publish(empty('STALE'));
    } else if (last.status === 'STALE') {
      this.previous = null;
      this.publish(candidate);
    }
  }
  needsCorrection() {
    return this.latest?.status === 'FAILED' && !this.onlyTestChanged(this.latest.target);
  }
}
